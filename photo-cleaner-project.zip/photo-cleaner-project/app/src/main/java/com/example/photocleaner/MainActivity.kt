package com.example.photocleaner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var resultText: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40,50,40,40) }
        val title = TextView(this).apply { text = "照片整理助手"; textSize = 26f }
        val safety = TextView(this).apply { text = "\n安全模式：目前只掃描照片，不刪除、不移動原照片。"; textSize = 17f }
        resultText = TextView(this).apply { text = "\n按下「開始掃描」後，會統計手機照片數量。"; textSize = 18f }
        val scanButton = Button(this).apply { text = "開始掃描"; setOnClickListener { requestPermissionAndScan() } }
        layout.addView(title); layout.addView(safety); layout.addView(scanButton); layout.addView(resultText); setContentView(layout)
    }
    private fun requestPermissionAndScan() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this, arrayOf(permission),100) else scanPhotos()
    }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if (requestCode==100 && grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED) scanPhotos() else resultText.text="沒有取得照片權限，因此沒有掃描任何照片。"
    }
    private fun scanPhotos() {
        var count=0
        contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,arrayOf(MediaStore.Images.Media._ID),null,null,null)?.use { count=it.count }
        resultText.text="掃描完成！\n\n手機照片數量：$count 張\n\n下一版再加入：\n• 疑似重複照片\n• 疑似截圖/下載照片\n• AI 協助分類\n• 使用者確認後才處理"
    }
}
